---
name: VAIBREPORT Terminal
colors:
  surface: '#fafaf4'
  surface-dim: '#dadad5'
  surface-bright: '#fafaf4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4ee'
  surface-container: '#eeeee8'
  surface-container-high: '#e8e8e3'
  surface-container-highest: '#e3e3dd'
  on-surface: '#1a1c19'
  on-surface-variant: '#46464b'
  inverse-surface: '#2f312d'
  inverse-on-surface: '#f1f1eb'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#0152d0'
  on-secondary: '#ffffff'
  secondary-container: '#346dea'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#00210b'
  on-tertiary-container: '#00984c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#dae1ff'
  secondary-fixed-dim: '#b3c5ff'
  on-secondary-fixed: '#001849'
  on-secondary-fixed-variant: '#003fa4'
  tertiary-fixed: '#62ff96'
  tertiary-fixed-dim: '#00e475'
  on-tertiary-fixed: '#00210b'
  on-tertiary-fixed-variant: '#005226'
  background: '#fafaf4'
  on-background: '#1a1c19'
  surface-variant: '#e3e3dd'
  slate-gray: '#5E6780'
  muted-border: '#C4C6D0'
  error-red: '#ba1a1a'
typography:
  display-lg:
    fontFamily: Chivo
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Chivo
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  section-header:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.1em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  mono-data:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  micro-label:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  nav-width: 256px
  top-bar-height: 64px
  container-max: 1280px
---

## Brand & Style

VAIBREPORT Terminal embodies a **Technical Minimalist** aesthetic, blending corporate sophistication with the raw, high-density information architecture of a network operations center. It is designed for institutional analysts and network operators who require precision, speed, and mathematical grounding.

The style is characterized by a "Blueprint" philosophy—using a subtle 24px dot grid to provide a sense of spatial calculation and structural integrity. It draws from **Neo-Brutalism** through its use of high-contrast borders and monospaced data, but tempers it with **Modern Corporate** sensibilities like backdrop blurs and a refined, off-white surface palette. The emotional response is one of absolute control, technical authority, and clinical efficiency.

## Colors

The palette is anchored by a "Bone" neutral base (#fafaf4), providing a warmer, more technical feel than pure white. 

- **Primary Black (#000000):** Used for core branding, primary action buttons, and high-level typography to ensure maximum contrast and authority.
- **Accent Blue (#0052D0):** Represents connectivity and active system states. It is the primary signal color for navigation highlights and key links.
- **Status Green (#00E475):** Reserved strictly for "Stable" or "Rising" system metrics and healthy signal indicators.
- **Slate Gray (#5E6780):** Used for metadata, labels, and secondary information to reduce visual noise in data-heavy views.
- **Error Red (#BA1A1A):** Used for critical alerts and destructive actions, often accompanied by motion (pulse/ping) to command attention.

## Typography

The typography system uses a triple-font approach to separate intent:
- **Chivo (Display/Headlines):** High-impact, sharp, and confident. Used for page titles and major section headings to establish a clear hierarchy.
- **Inter (Body):** A neutral workhorse for long-form reading and descriptive text.
- **JetBrains Mono (Data/Labels):** The technical backbone of the UI. Used for all system-generated values, status chips, and button labels to evoke a terminal/code environment.

**Scaling Note:** On mobile devices, `display-lg` should scale down to 32px (matching desktop `headline-lg`), and `headline-lg` should scale to 24px to maintain readability.

## Layout & Spacing

The system follows a **Fixed-Fluid Hybrid** model. The sidebar remains a fixed 256px on desktop, while the main content canvas flows within a maximum width of 1280px.

- **Grid:** A 12-column grid is used for the main content area with 24px (gutter) spacing.
- **Rhythm:** An 8px base unit governs all internal padding and component heights.
- **Vertical Hierarchy:** Use large 80px - 100px gaps (Section spacing) to separate major modules, and 32px gaps for grouping related elements.
- **Responsive Behavior:** On tablet, the sidebar collapses into a hidden drawer. On mobile, horizontal margins shrink to 16px, and grid columns stack vertically.

## Elevation & Depth

Elevation is achieved primarily through **Tonal Layering** and **Technical Outlines** rather than soft shadows.

1.  **The Base:** The `surface` (#fafaf4) with a dot-grid pattern.
2.  **Container Low:** Used for the sidebar and secondary content areas, creating depth through slight value shifts (#f4f4ee).
3.  **The Glass Layer:** The top navigation uses an 80% opacity blur (`backdrop-blur-md`) to feel elevated above the content while maintaining context.
4.  **Borders:** Depth is defined by `outline-variant` (#c8c5cb) borders. Primary cards use a 2px left-border accent in the `primary` color to indicate significance.
5.  **Shadows:** When used (e.g., floating buttons or cards), shadows are extremely subtle: `0px 4px 20px rgba(0,0,0,0.04)`, providing just enough lift to separate from the grid.

## Shapes

The shape language is "Calculated Softness." Elements are predominantly rectangular to maintain a technical feel, but with small, precise corner radii to prevent the UI from feeling aggressive.

- **Standard Radius:** 0.25rem (4px) for small components like inputs and badges.
- **Large Radius:** 0.5rem (8px) for cards, sidebars, and primary buttons.
- **Pill:** Reserved exclusively for status indicators, "live" badges, and the theme toggle button.
- **Interactive States:** Buttons should use a slight scale-down effect (`active:scale-95`) to provide tactile feedback without relying on skeuomorphic shadows.

## Components

### Buttons
- **Primary:** Solid Black (#000000) with White text. Labels are uppercase Mono-Data. Usually includes a 18px icon for directional cues.
- **Outline:** 2px solid border. Switches to solid fill on hover.
- **Ghost:** Background-less with Slate Gray text, moving to Primary on hover.

### Input Fields
- **Search/Query:** Background `surface-container-low`, no border until focused. Focus state triggers a 1px ring of Accent Blue and expands the field width.

### Cards & Widgets
- **Metric Cards:** Use `surface-container-lowest` (pure white) with a 1px outline. Must include a sparkline or bar chart visual for trend data.
- **Promotion/Hero Cards:** High-contrast (Primary Black background) with heavy typography and a single floating decorative element (e.g., a blurred gradient sphere) to break the grid.

### Signals & Status
- **Signal Dots:** 12px circles. "Rising" and "Critical" states should include a pulse or ping animation.
- **Badges:** Small, uppercase mono text with high-contrast background fills (e.g., Tertiary Fixed for "Stable").